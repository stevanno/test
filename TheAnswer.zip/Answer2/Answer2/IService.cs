﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace Answer2
{
    [DataContract]
    public class User
    {
        [DataMember]
        public string FacebookID;
        [DataMember]
        public string Name;
        [DataMember]
        public string Age;
        [DataMember]
        public string Friends;
        [DataMember]
        public bool Matched;
        [DataMember]
        public string Status;
    
    }
    [ServiceContract]
    public interface IService
    {
        //POST
        [OperationContract]
        [WebInvoke(UriTemplate = "", Method = "POST")]
        User CreateUser(User createUser);

        //GET
        [OperationContract]
        [WebGet(UriTemplate = "{id}")]
        User GetUser(string id);
        [OperationContract]
        [WebGet(UriTemplate = "")]
        List<User> GetMatchUser();
    }

}