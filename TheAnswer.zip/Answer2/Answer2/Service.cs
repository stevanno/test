﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Activation;
using System.ServiceModel;

namespace Answer2
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class Service : IService
    {
        List<User> UserObj = new List<User>();
        
        public User GetUser(string id)
        {
            return UserObj.FirstOrDefault(e => e.FacebookID.Equals(id));
        }
        public List<User> GetMatchUser()
        {
           return UserObj.Where(x=>x.Matched==true).ToList();
           
        }
        public User CreateUser(User createUser)
        {
          
                var MyList = UserObj.Where(x => x.Age == createUser.Age && x.Friends == createUser.Friends).ToList();

                if (MyList.Count == 1)
                {
                    createUser.Matched = true;
                    string FbID = "";
                    foreach (var item in MyList)
                    {
                        FbID = item.FacebookID;
                    }
                    //UPDATE
                    foreach (var item in UserObj)
                    {
                        if (item.FacebookID == FbID)
                        {
                            item.Matched = true;
                        }
                    }

                }
                else
                {
                    createUser.Matched = false;
                }
                createUser.Status = "OK";

                UserObj.Add(createUser);


                return createUser;
        }

    }
}