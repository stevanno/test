﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Answer1
{
    public class Data
    {
        public string userid { get; set; }
        public DateTime time { get; set; }
        public string longitude { get; set; }
        public string latitude { get; set; }
      
  
    }
}