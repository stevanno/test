﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Answer1
{
    public class DataProcess
    {
        static public class TheData
        {
            static private readonly List<Data> _data = new List<Data>();
            static public void SaveData(string userid, string longitude, string latitude)
            {
                
                Data x = new Data();
                x.userid = userid;
                x.longitude = longitude;
                x.latitude = latitude;
                x.time = DateTime.Now;
                _data.Add(x);
            }
            static public List<Data> getdata()
            {
                return _data;
            }

        }
    }
}