﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Answer3
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            List<string> id = new List<string>();
            
            for (int i = 1; i < 201; i++)
            {
                
                    foreach (var item in Calc.CalculateResult(i).ToList())
                    {
                        if (item.ToString().Contains("0*0"))
                        {
                            string ID = item.Split('=').First();
                            id.Add(ID);
                        }
                    }
               
            }
            var result = id.Distinct().ToList().Count;
            Label1.Text = (200 - Convert.ToInt32(result)).ToString();

           
        }
       
       
        protected void Button1_Click(object sender, EventArgs e)
        {
            List<string> Answer = new List<string>();
            Answer = Calc.CalculateResult(Convert.ToInt32(TextBox1.Text));
            TextBox2.Text = String.Join(Environment.NewLine, Answer);
        }
    }
}