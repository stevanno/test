﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Answer3
{
    public class Calc
    {
        public static List<string> CalculateResult(int a)
        {
            List<string> rList = new List<string>();
            string result = "";
            for (int i = 0; i * i <= a; i++)
            {
                for (int j = i; j * j <= a; j++)
                {
                    for (int k = j; k * k <= a; k++)
                    {
                        for (int l = k; l * l <= a; l++)
                        {

                            if (i * i + j * j + k * k + l * l == a)
                            {

                                result = (a + " = " + i + "*" + i + " + "
                                             + j + "*" + j + " + ");
                                result += (k + "*" + k + " + "
                                              + l + "*" + l);

                                rList.Add(result);


                            }
                        }
                    }
                }
            }
            return rList;
        } 
    }
}